=====
Фронтенд для дипломного проекта
=====
Quick start
-----------
1. Добавьте поле "frontend" в параметры INSTALLED_APPS:

INSTALLED_APPS = [
        ...
        'frontend',
    ]

2.Добавьте URL конфигурацию в свой проект urls.py:

url(r'^frontend/', include('frontend.urls')),

3. Выполните `python manage.py migrate`.