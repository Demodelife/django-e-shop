var mix = {
    methods: {
        submitPayment () {
            this.postData('/api/payment/', )
        }
    }
}